package com.fingerprint.fingerprintbiometryinandroid;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.biometric.BiometricManager;
import androidx.biometric.BiometricPrompt;
import androidx.core.content.ContextCompat;

import java.util.Objects;
import java.util.concurrent.Executor;

public class MainActivity extends AppCompatActivity {

    private Button logInBtn;
    private BiometricManager biometricManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Objects.requireNonNull(getSupportActionBar()).hide();
        initWidgets();
        fingerPrintImpl();
    }

    private void initWidgets() {
        logInBtn = findViewById(R.id.login_btn);
        biometricManager = androidx.biometric.BiometricManager.from(this);
    }

    private void fingerPrintImpl() {
        switch (biometricManager.canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_STRONG)) {
            case BiometricManager.BIOMETRIC_SUCCESS:
                Toast.makeText(MainActivity.this, "The user can successfully authenticate.", Toast.LENGTH_SHORT).show();
                break;
            case BiometricManager.BIOMETRIC_ERROR_NO_HARDWARE:
                logInBtn.setVisibility(View.GONE);
                Toast.makeText(MainActivity.this, "The user can't authenticate because there is no suitable hardware", Toast.LENGTH_SHORT).show();
                break;
            case BiometricManager.BIOMETRIC_ERROR_HW_UNAVAILABLE:
                logInBtn.setVisibility(View.GONE);
                Toast.makeText(MainActivity.this, "The user can't authenticate because the hardware is unavailable.", Toast.LENGTH_SHORT).show();
                break;
            case BiometricManager.BIOMETRIC_ERROR_NONE_ENROLLED:
                Toast.makeText(MainActivity.this, "The user can't authenticate because no biometric or device credential is enrolled.", Toast.LENGTH_LONG).show();
                logInBtn.setVisibility(View.GONE);
                break;
            case BiometricManager.BIOMETRIC_ERROR_SECURITY_UPDATE_REQUIRED:
                Toast.makeText(MainActivity.this, "The user can't authenticate because a security vulnerability has been discovered with one or more hardware sensors", Toast.LENGTH_LONG).show();
                logInBtn.setVisibility(View.GONE);
                break;
            case BiometricManager.BIOMETRIC_ERROR_UNSUPPORTED:
                Toast.makeText(MainActivity.this, "The user can't authenticate because the specified options are incompatible with the current Android version.", Toast.LENGTH_LONG).show();
                logInBtn.setVisibility(View.GONE);
                break;
            case BiometricManager.BIOMETRIC_STATUS_UNKNOWN:
                Toast.makeText(MainActivity.this, "Unable to determine whether the user can authenticate", Toast.LENGTH_LONG).show();
                logInBtn.setVisibility(View.GONE);
                break;
        }

        Executor executor = ContextCompat.getMainExecutor(MainActivity.this);
        final BiometricPrompt bP = new BiometricPrompt(MainActivity.this, executor, new BiometricPrompt.AuthenticationCallback() {
            @Override
            public void onAuthenticationError(int errorCode, @NonNull CharSequence errorString) {
                super.onAuthenticationError(errorCode, errorString);
                Toast.makeText(getApplicationContext(), "Auth Error", Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onAuthenticationSucceeded(@NonNull BiometricPrompt.AuthenticationResult result) {
                super.onAuthenticationSucceeded(result);
                Toast.makeText(getApplicationContext(), "Login Successful", Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onAuthenticationFailed() {
                super.onAuthenticationFailed();
                Toast.makeText(getApplicationContext(), "Failed to authenticate", Toast.LENGTH_SHORT).show();
            }

        });

        final BiometricPrompt.PromptInfo promptInfo = new BiometricPrompt.PromptInfo.Builder()
                .setTitle("Biometry login for my app")
                .setDescription("Use your fingerprint to login")
                .setConfirmationRequired(true)
                .setNegativeButtonText("Cancel")
                .build();

        logInBtn.setOnClickListener(v -> bP.authenticate(promptInfo));
    }
}